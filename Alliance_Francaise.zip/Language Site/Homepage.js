 //Get aLL dropdoms from the document 
const dropdowns = document.querySelectorAll('.dropdown');

//Loop through aLL dropdown eLements 
dropdowns.forEach(dropdown => { 
//Get inner eLements from each dropdom 
const select = dropdown.querySelector('.select'); 
const caret = dropdown.querySelector('.caret'); 
const menu = dropdown.querySelector('.menu'); 
const options = dropdown.querySelectorAll('.menu li'); 
const selected = dropdown.querySelector('.selected'); 

/*
we are usirrg this method tn order ro hove 
muLtipLe dropdom menus on the page work */

//Add a cLick event to the seLect element
select.addEventListener('click', () => { 
//Add the cLicked select styles to the select 
select.classList.toggle('select-clicked'); 
//Add the rotate styles to the caret element 
caret.classList.toggle('caret-rotate'); 
//Add the opm sty es to tne enu e Lei, nt 
menu.classList.toggle('menu-open');
});


//Loop through ULL option e 
options.forEach(option => { 
//Add 0 cLick event to tr 
option.AddEventListener('click', () => { 
//Change selected inner 
selected.innerText = option.innerText; 
//Add the cLicked se Lec 
select.classList.remove('select-clicked');


/*e LeMents 
he option eLenrgnt 
r text to cLicJeed option inner tex 
ption. InnerText; 
ct styles to the select element 
e( 'select-clicked');
[7/2, 8:32 PM] lenny🏀: options. For Each(option=> 
/lAdd a cLick event to the option e cement 
option. AddEvent Listener( 'click', «» ·> 
//chonge seLected inner text to cLicked option inner text 
selected. InnerText· option. InnerText; 

/lAdd the cLicked seLect styles to the select eLement 
select. classList. Remove( 'select-clicked'); 
/lAdd the rotate styles to the carel eLement */



caret.classList.remove('caret-rotate'); 
//Add the open styLes to the menu eLement 

menu.classList.remove('menu-open'); 
//Remove active cLass frm oLL option element: 
options.forEach(option => {
  option.classList.remove('active');
});

lAdd active cLass to clicked option eLemertt 
option.classList.add('active');

    });
  });
});


/* //HUU Lire LLiLneu» e LCLL» Ly Le» Lu ure ae LCLL e Lemerl& 
select. classList. Remve( 'select-clicked '); 

/lAdd the rotate styLes to the caret eLement 
caret. classList. Remove« 'caret-rotate'); 
//Add the open styles to the menu element 

enu. classList. Remove( 'menu-open'); 
{Remove active cLass frm aLL option eLements 

ptions. ForEach(option a> 
option. classList. Remove« 'active' » ;

lAdd active cLass to clicked option eLemertt 
ption. classList. Addi 'active');